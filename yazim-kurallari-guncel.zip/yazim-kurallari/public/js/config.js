// Şifreleri değiştirmek istersen sadece burayı düzenle.
// Dikkat: Türkçe büyük İ ve küçük ı/i farklı karakterlerdir.
window.APP_CONFIG = {
  SITE_PASSWORD: 'Yİlmaz',
  ADMIN_PASSWORD: 'Yİlmaz',
  SESSION_KEY: 'yk_session_v2',
  ADMIN_SESSION_KEY: 'yk_admin_session_v2',
  MAX_FAILED_ATTEMPTS: 5,
  LOCK_MINUTES: 10
};
