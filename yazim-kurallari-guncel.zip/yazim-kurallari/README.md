# Yazım Kuralları

GitHub Pages için hazırlanmış, şifreli ve modern TYT yazım kuralları test sitesi.

## Şifre Değiştirme

Dosya: `public/js/config.js`

```js
SITE_PASSWORD: 'Yİlmaz',
ADMIN_PASSWORD: 'Yİlmaz',
MAX_FAILED_ATTEMPTS: 5,
LOCK_MINUTES: 10
```

## Soru Ekleme

1. Siteye gir.
2. Sağ üstten **Admin** bölümüne gir.
3. Şifreyi yaz.
4. Formdan test adı, soru, A-B-C-D-E şıkları, doğru cevap, yanlış/önemli kelime ve açıklamayı ekle.

Admin panelden eklenen sorular GitHub Pages yüzünden sadece o tarayıcıda kalır. Başka cihaza aktarmak için:

- Admin > **Tam JSON Yedeği Dışa Aktar**
- Diğer cihazda Admin > **JSON İçe Aktar**

## Giriş Kayıtları

Admin panelde giriş kayıtları görünür. Şunlar tutulur:

- Başarılı / başarısız giriş
- Tarih ve saat
- Site/admin alanı
- Tarayıcı, cihaz, ekran ve saat dilimi
- 5 yanlış deneme sonrası 10 dakika kilitleme

Not: GitHub Pages statik olduğu için gerçek IP adresi alınamaz.

## Kodda Sabit Soru Düzenleme

Dosya: `public/js/data.js`

Her soru şu yapıda tutulur:

```js
{
  id: 'benzersiz-id',
  rule: 'Konu başlığı',
  text: 'Soru metni',
  options: ['A seçeneği', 'B seçeneği', 'C seçeneği', 'D seçeneği', 'E seçeneği'],
  answer: 'C',
  wrongWord: 'ezberlenecek kelime',
  explanation: 'Kısa açıklama'
}
```
